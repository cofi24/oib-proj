




export type CreateFiscalReceiptItemDTO = {
  perfumeId: number;
  perfumeName: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
};