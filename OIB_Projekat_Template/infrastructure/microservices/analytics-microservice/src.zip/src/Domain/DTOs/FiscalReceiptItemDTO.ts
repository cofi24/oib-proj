export type FiscalReceiptItemDTO = {
  perfumeId: number;
  perfumeName: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
};