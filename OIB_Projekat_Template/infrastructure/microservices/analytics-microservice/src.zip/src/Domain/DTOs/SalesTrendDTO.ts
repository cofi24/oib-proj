export interface SalesTrendDTO {
  label: string;
  prodato: number;
  zarada: number;
}
