export interface TopPerfumeDTO {
  naziv: string;
  prodaja: number;
  prihod: number;
}
