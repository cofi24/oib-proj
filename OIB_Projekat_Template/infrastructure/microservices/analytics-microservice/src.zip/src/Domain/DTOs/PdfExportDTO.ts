export class PdfExportDTO {
  fileName!: string;
  buffer!: Buffer;
}
