export class CreateSalesAnalysisReportDTO {
  nazivIzvestaja!: string;
  opis!: string;
  period!: string; 
  ukupnaProdaja!: number;
  ukupnaZarada!: number;
}
