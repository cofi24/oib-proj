export enum AuditLogType {
  INFO = "INFO",
  WARNING = "WARNING",
  ERROR = "ERROR"
}