import PDFDocument from 'pdfkit';
import { IPdfExportService } from '../Domain/services/IPdfExportService';
import{ FiscalReceiptDTO } from '../Domain/DTOs/FiscalReceiptDTO';
import { SalesAnalysisReportDTO } from '../Domain/DTOs/SalesAnalysisReportDTO';




export class PdfExportService implements IPdfExportService {

  async generateReportPdf(report: SalesAnalysisReportDTO): Promise<Buffer> {
    return new Promise((resolve) => {
      const doc = new PDFDocument({ margin: 50 });
      const chunks: Buffer[] = [];

      doc.on("data", (c) => chunks.push(c));
      doc.on("end", () => resolve(Buffer.concat(chunks)));

      /* ===== HEADER ===== */
      doc
        .rect(0, 0, doc.page.width, 90)
        .fill("#1f2937");

      doc
        .fillColor("white")
        .fontSize(22)
        .text("IZVEŠTAJ ANALIZE PRODAJE", 50, 30);

      doc.moveDown(3);
      doc.fillColor("#111827");

      /* ===== META INFO ===== */
      this.drawCard(doc, () => {
        doc.fontSize(11);
        doc.text(`ID izveštaja: ${report.id}`);
        doc.text(`Naziv: ${report.nazivIzvestaja}`);
        doc.text(`Period: ${report.period}`);
        doc.text(`Kreirano: ${report.createdAt}`);
      });

      /* ===== DESCRIPTION ===== */
      this.drawCard(doc, () => {
        doc.fontSize(11).text("Opis", { underline: true });
        doc.moveDown(0.5);
        doc.text(report.opis);
      });

      /* ===== SUMMARY ===== */
      this.drawCard(doc, () => {
        doc.fontSize(12).font("Helvetica-Bold");
        doc.text(`Ukupna prodaja: ${report.ukupnaProdaja}`);
        doc.moveDown(0.5);
        doc.text(`Ukupna zarada: ${report.ukupnaZarada}`);
        doc.font("Helvetica");
      });

      doc
        .fontSize(9)
        .fillColor("#6b7280")
        .text("Generisano iz Analytics mikroservisa.", 50, doc.page.height - 40);

      doc.end();
    });
  }

  async generateReceiptPdf(receipt: FiscalReceiptDTO): Promise<Buffer> {
    return new Promise((resolve) => {
      const doc = new PDFDocument({ margin: 40 });
      const chunks: Buffer[] = [];

      doc.on("data", (c) => chunks.push(c));
      doc.on("end", () => resolve(Buffer.concat(chunks)));

      /* ===== HEADER ===== */
      doc
        .rect(0, 0, doc.page.width, 80)
        .fill("#111827");

      doc
        .fillColor("white")
        .fontSize(20)
        .text("FISKALNI RAČUN", 40, 30);

      doc.moveDown(3);
      doc.fillColor("#111827");

      /* ===== RECEIPT INFO ===== */
      this.drawCard(doc, () => {
        doc.fontSize(11);
        doc.text(`Broj računa: ${receipt.brojRacuna}`);
        doc.text(`Datum: ${new Date(receipt.createdAt).toLocaleString("sr-RS")}`);
        doc.text(`Tip prodaje: ${receipt.tipProdaje}`);
        doc.text(`Način plaćanja: ${receipt.nacinPlacanja}`);
      });

      /* ===== ITEMS TABLE ===== */
      this.drawCard(doc, () => {
        doc.fontSize(13).font("Helvetica-Bold").text("Stavke");
        doc.moveDown(1);

        const headers = ["Parfem", "Kol.", "Cena", "Ukupno"];
        const colX = [40, 300, 370, 460];

        doc.fontSize(10);
        headers.forEach((h, i) => doc.text(h, colX[i], doc.y));
        doc.moveDown(0.5);

        doc.moveTo(40, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);

        receipt.items.forEach((item) => {
          doc.fontSize(9);
          doc.text(item.perfumeName, colX[0], doc.y, { width: 240 });
          doc.text(item.quantity.toString(), colX[1], doc.y);
          doc.text(`${item.unitPrice} RSD`, colX[2], doc.y);
          doc.text(`${item.lineTotal} RSD`, colX[3], doc.y);
          doc.moveDown(0.7);
        });
      });

      /* ===== TOTAL ===== */
      this.drawCard(doc, () => {
        doc.font("Helvetica-Bold").fontSize(14);
        doc.text(
          `IZNOS ZA NAPLATU: ${receipt.iznosZaNaplatu.toLocaleString("sr-RS")} RSD`,
          { align: "right" }
        );
      });

      doc
        .fontSize(8)
        .fillColor("#6b7280")
        .text(
          "Generisano iz Analytics mikroservisa.",
          40,
          doc.page.height - 40,
          { align: "center" }
        );

      doc.end();
    });
  }

  /* ===== Helper for card layout ===== */
  private drawCard(doc: PDFKit.PDFDocument, content: () => void) {
    const startY = doc.y;
    doc.moveDown(0.5);
    content();
    const endY = doc.y;

    doc
      .roundedRect(30, startY - 10, doc.page.width - 60, endY - startY + 20, 8)
      .stroke("#d1d5db");

    doc.moveDown(1);
  }
}